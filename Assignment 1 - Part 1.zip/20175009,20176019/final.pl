processes([1,2,3,4]).
request(1,r1).

request(3,r2).



allocated(1,r2).
allocated(2,r1).
allocated(3,r1).
allocated(4,r2).



findrequested([],[]).


findrequested([H|T],[X|R]) :-

allocated(H,_),
  request(H,_),
  X is H,
findrequested(T,R).

findrequested( [H|T],R) :-
findrequested(T,R).




findNotrequested([],[]).
findNotrequested([H|T],[V|R]) :-

allocated(H,_),

  \+ request(H,_),

  V is H,
  findNotrequested(T,R).
findNotrequested([H|T],R) :-
  findNotrequested(T,R).


results(Res):-
processes(P),

findrequested(P,R),
findNotrequested(P,M),
(   checkDeadlock(M)-> Res = false ;
append(M,R,Res)).




checkDeadlock([]).


%checkDeadlock(L):-
%list_empty(L,E),
 % E = true .


%list_zerolength(List, Empty) :-
  %  length(List, Len),
   % (   Len == 0
   % ->  Empty = true
   % ;   Empty = false
   % ).

%list_empty([], true).
%list_empty([_|_], false).












